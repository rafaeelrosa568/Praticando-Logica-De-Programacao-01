//* 5 - Faça um programa que receba receba o salário de um funcionário e o 
//percentual de aumento, mostre o valor do aumento e o novo salário.
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;


public class Questao5 {
   
    public static void main(String[] args) {
        // Declaração de variaveis
        double salario, percentual, aumentosalario, novosalario;
        Scanner teclado = new Scanner (System.in);
        // Entrada de dados digitados no teclado
        System.out.println("Digite o valor do salário: ");
        salario = teclado.nextDouble();
        System.out.println("Digite o percentual de aumento");
        percentual = teclado.nextDouble();
        // Processamento do dados
        aumentosalario = (salario * percentual/100);
        novosalario = salario + aumentosalario;
        // Saída dos dados
        System.out.println("O valor do aumento foi " + aumentosalario);
        System.out.println("O valor do novo salário é: " + novosalario);
        
        
        
    }
}
