/*8 - Faça um programa que receba o valor de um depósito e o valor da taxa 
*de juros, calcule e mostre o valor 
*do rendimento e valor total após o rendimento.
*/
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;


public class Questao8 {
  
    public static void main(String[] args) {
        double deposito, juros, rendimento, valortotal;
        Scanner teclado = new Scanner (System.in);
        System.out.println("Informe o valor do deposito; ");
        deposito = teclado.nextDouble();
        System.out.println("Informe o valor da taxa de juros; ");
        juros = teclado.nextDouble();
        rendimento = (juros * juros/100);
        valortotal = (deposito + rendimento);
        System.out.println("O seu rendimento da poupança: " + rendimento);
        System.out.println("O valor total após rendimento: " + valortotal);
        
    }
}
