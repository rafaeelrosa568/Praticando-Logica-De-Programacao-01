/*9 - Faça um programa que receba o ano de nascimento e ano atual, 
*calcule e mostre a idade atual e a idade em 2080.
*/
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;


public class Questao9 {
    
    public static void main(String[] args) {
        int anonasci, anoatual, anofuturo, idade;
        Scanner teclado = new Scanner (System.in);
        System.out.println("Informe seu ano de nascimento: ");
        anonasci = teclado.nextInt();
        System.out.println("Informe o ano atual: ");
        anoatual = teclado.nextInt();
        idade = (anoatual - anonasci);
        anofuturo = (2080 - anonasci);
        System.out.println("Sua idade atual é; " + idade);
        System.out.println("Sua idade em 2080 será: " + anofuturo);
        
    }
}
