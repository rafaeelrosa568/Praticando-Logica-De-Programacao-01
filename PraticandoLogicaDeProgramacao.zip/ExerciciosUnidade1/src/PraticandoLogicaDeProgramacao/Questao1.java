
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;

    public class Questao1 {

    
    public static void main(String[] args) {
        // Declaração da variável
        int n1, n2, n3, n4, soma;
        Scanner teclado = new Scanner(System.in);
        // Entrada de dados
        System.out.println("Digite o 1º número: ");
        n1 = teclado.nextInt(); 
        System.out.println("Digite o 2º número: ");
        n2 = teclado.nextInt(); 
        System.out.println("Digite o 3º número: ");
        n3 = teclado.nextInt();
        System.out.println("Digite o 4º número: ");
        n4 = teclado.nextInt();
        // Processamento
        soma = n1 + n2 + n3 + n4;
        //saida de dados
        System.out.println("soma " + soma );
    }
    
}
