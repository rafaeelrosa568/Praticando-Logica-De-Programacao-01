//* 6 - Receba o salário base de um funcionário, calcule e mostre o 
//salário a receber, sabendo-se que o funcionário tem 5% de gratificação sobre 
//o salário base e paga imposto de 7% sobre este salário.
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;


public class Questao6 {
   
    public static void main(String[] args) {
        // Declaração de variaveis
        double salariobase, salarioreceber, gratifi, imposto;
        Scanner teclado = new Scanner (System.in);
        // Entrada dos dados
        System.out.println("Informe o salario base: ");
        salariobase = teclado.nextDouble();
        // Processamento de dados
        gratifi = (salariobase * 5/100);
        imposto = (salariobase * 7/100);
        salarioreceber = (salariobase + gratifi) - imposto;
        //saída de dados
        System.out.println("Gratificação CCT de 5 % ");
        System.out.println("Imposto de IRPF de 7 % ");
        System.out.println("Salário liquido a receber: " + salarioreceber);
        
        
        
    }
    
}
