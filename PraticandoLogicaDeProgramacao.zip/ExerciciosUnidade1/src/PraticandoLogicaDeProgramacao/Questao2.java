//* Faça um programa que receba 3 notas, calcule e mostre a média aritmética entre elas.
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;

public class Questao2 {
    
    public static void main(String[] args) {
            // Declaração de variaveis
        double nota1, nota2, nota3, media;
        Scanner entrada = new Scanner (System.in);
            // Entrada das notas digitadas no teclado
        System.out.println("Entre com a 1º nota: ");
        nota1 = entrada.nextDouble();
        System.out.println("Entre com a 2º nota: ");
        nota2 = entrada.nextDouble();
        System.out.println("Entre com a 3º nota: ");
        nota3 = entrada.nextDouble();
            // Processamentos do cálculo
        media = (nota1 + nota2 + nota3)/3;
            // Saída de dados (resultado da soma)
        System.out.println("A media aritmética " + media );
        
    }
}
