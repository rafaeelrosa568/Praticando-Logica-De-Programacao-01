//*Faça um programa que receba 3 notas 
//e os seus respectivos pesos, calcule e mostre a média ponderada.
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;

public class Questao3 {
    
    public static void main(String[] args) {
        // Declaração da variavel
        double nota1, nota2, nota3, pond, notaf;
        Scanner teclado = new Scanner (System.in);
        // Entrada das nota digitadas no teclado
        System.out.println("Digite a 1º nota ");
        System.out.println("Peso 1 sobre a primeira nota");
        nota1 = teclado.nextDouble();
        System.out.println("Digite a 2º nota ");
        System.out.println("Peso 2 sobre a segunda nota");
        nota2 = teclado.nextDouble();
        System.out.println("Digite a 3º nota ");
        System.out.println("Peso 3 sobre a terceira nota");
        nota3 = teclado.nextDouble();
        // Processamentos dos dados
        pond = (nota1 * 1) + (nota2 * 2 ) + (nota3 * 3);
        notaf = pond / 3;
        // Saída dos dados (Resultado das somas)
        System.out.println("Nota final" + notaf);
        
    }
    
}
