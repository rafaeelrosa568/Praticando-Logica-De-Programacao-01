//7 - Faça um programa que receba o salário base de um funcionário,
//calcule e mostre o seu salário a receber, 
//sabendo-se que o funcionário tem gratificação de R$ 50 
//e imposto de 10% sobre o salário base.
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;

public class Questao7 {
  
    public static void main(String[] args) {
        // Declaração de variaveis
        double salariobase, salarioliqui, imposto;
        Scanner  teclado = new Scanner(System.in);
        // Entrada de dados
        System.out.println("Informe o valor do salário");
        salariobase = teclado.nextDouble();
        //processamento dos dados
        imposto = (salariobase * 10/100);
        salarioliqui = (salariobase + 50) - imposto;
        // Saída de dados
        System.out.println("Gratificação de R$ 50,00 sobre salário base");
        System.out.println("Imposto de 10 % ");
        System.out.println("Salario liquido a receber: " + salarioliqui);
        
        
    }
    
}
