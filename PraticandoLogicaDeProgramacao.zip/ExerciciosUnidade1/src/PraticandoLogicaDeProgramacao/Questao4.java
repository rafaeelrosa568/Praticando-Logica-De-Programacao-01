package PraticandoLogicaDeProgramacao;

import java.util.Scanner;

public class Questao4 {

    public static void main(String[] args) {
        // Declaração de variaveis
        double salario, aumentosalario, salarioreajustado;
        Scanner teclado = new Scanner(System.in);
        // Entrada dos dados digitados no teclado
        System.out.print("Digite o valor do salário: ");
        salario = teclado.nextDouble();
        // Procesamentos de dados
        aumentosalario = (salario * 25 / 100);
        salarioreajustado = salario + aumentosalario;

        // Saída de dados
        System.out.println("Valor do salário com aumento de 25% " + salarioreajustado);

    }

}
