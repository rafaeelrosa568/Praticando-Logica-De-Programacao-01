/*10 – O valor de um carro novo é igual a soma do preço de fábrica 
*com o percentual de lucro do distribuidor
*o percentual dos impostos aplicados ao preço de fábrica. 
*Entre com o preço de fábrica o percentual de lucro dos distribuidores 
*e o percentual dos impostos, ao final mostre, 
*o valor do lucro do distribuidor o valor correspondente aos impostos 
*e o preço de venda do veículo.
*/
package PraticandoLogicaDeProgramacao;

import java.util.Scanner;


public class Questao10 {
    
    public static void main(String[] args) {
        double precofabrica, percenlucro,  percenimposto, precofinal;
        double impostos, lucro, precoimposto;
        Scanner teclado = new Scanner (System.in);
        System.out.println("Informe o preço de fabrica do seu automovel: ");
        precofabrica = teclado.nextDouble();
        System.out.println("Informe o percentual de lucro: ");
        percenlucro = teclado.nextDouble();
        System.out.println("Informe o percentual do imposto: ");
        percenimposto = teclado.nextDouble();
        impostos = (precofabrica * percenlucro/100);
        lucro = (precofabrica * percenimposto/100);
        precofinal = (precofabrica + impostos + lucro);
        System.out.println("O lucro do distribuidor; " + lucro);
        System.out.println("Impostos: " + impostos);
        System.out.println("Preço de venda do veículo: " + precofinal);
    }
}
